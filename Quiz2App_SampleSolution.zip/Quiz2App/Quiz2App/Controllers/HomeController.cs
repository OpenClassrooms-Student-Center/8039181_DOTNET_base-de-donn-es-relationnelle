﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Quiz2App.Models;
using Quiz2App.Data;
using Microsoft.EntityFrameworkCore;

namespace Quiz2App.Controllers
{
    public class HomeController : Controller
    {
        // added by students
        private readonly Quiz2DbContext db;

        // added by students
        public HomeController(Quiz2DbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // added by students
        public ActionResult Quiz2()
        {
            var result = db.Cars.FromSql($"EXECUTE dbo.Quiz2Proc");
            return View(result);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
