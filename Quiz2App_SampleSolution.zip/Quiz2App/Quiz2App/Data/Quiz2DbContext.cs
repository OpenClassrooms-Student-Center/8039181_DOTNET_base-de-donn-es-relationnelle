﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Quiz2App.Data
{
    public partial class Quiz2DbContext : DbContext
    {
        public Quiz2DbContext()
        {
        }

        public Quiz2DbContext(DbContextOptions<Quiz2DbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cars> Cars { get; set; }
        public virtual DbSet<Makes> Makes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // MS scaffolding message removed or commented out by students
//To protect potentially sensitive information in your connection string, you should move it out of source code.See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.

            //if (!optionsBuilder.IsConfigured)
            //{
            //    optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=Quiz2Db;Trusted_Connection=True;");
            //}
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<Cars>(entity =>
            {
                entity.HasIndex(e => e.MakeId);

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.Cars)
                    .HasForeignKey(d => d.MakeId);
            });
        }
    }
}
