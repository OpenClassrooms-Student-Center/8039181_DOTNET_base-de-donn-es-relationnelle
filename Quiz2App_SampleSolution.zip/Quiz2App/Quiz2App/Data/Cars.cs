﻿using System;
using System.Collections.Generic;

namespace Quiz2App.Data
{
    public partial class Cars
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public string Model { get; set; }
        public string PicUrl { get; set; }
        public int MakeId { get; set; }

        public virtual Makes Make { get; set; }
    }
}
