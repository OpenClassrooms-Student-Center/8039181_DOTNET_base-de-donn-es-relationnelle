﻿using System;
using System.Collections.Generic;

namespace Quiz2App.Data
{
    public partial class Makes
    {
        public Makes()
        {
            Cars = new HashSet<Cars>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Cars> Cars { get; set; }
    }
}
